# 图标分类索引

共 **177** 个图标，按以下分类组织：

- **基础操作 Basic Actions**（19个）— `icons-basic.md`
- **导航 Navigation**（16个）— `icons-navigation.md`
- **媒体 Media**（14个）— `icons-media.md`
- **通讯 Communication**（6个）— `icons-communication.md`
- **用户与社交 User & Social**（6个）— `icons-user.md`
- **系统与状态 System & Status**（14个）— `icons-system.md`
- **安全 Security**（7个）— `icons-security.md`
- **文件与文档 Files & Docs**（12个）— `icons-files.md`
- **开发工具 Development**（15个）— `icons-dev.md`
- **商业与电商 Business & E-commerce**（10个）— `icons-business.md`
- **时间与日程 Time & Schedule**（3个）— `icons-time.md`
- **天气与自然 Weather & Nature**（10个）— `icons-weather.md`
- **旅行与地点 Travel & Location**（4个）— `icons-travel.md`
- **教育与知识 Education**（5个）— `icons-education.md`
- **创意与设计 Creative & Design**（7个）— `icons-creative.md`
- **食物与饮品 Food & Drink**（5个）— `icons-food.md`
- **游戏与趣味 Games & Fun**（7个）— `icons-games.md`
- **科学与太空 Science & Space**（6个）— `icons-science.md`
- **其他 Misc**（11个）— `icons-misc.md`

## 使用方法

1. 根据语义在对应分类文件中查找图标名称
2. 获取SVG代码直接使用，或引用 `assets/icons/<name>.svg` 文件
3. 图标默认 `stroke="currentColor"`，可通过CSS `color` 属性控制颜色
