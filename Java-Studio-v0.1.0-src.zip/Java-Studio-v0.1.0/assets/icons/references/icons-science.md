# 科学与太空 Science & Space

共 6 个图标

## satellite

**关键词**: 卫星,satellite,space,orbit,communication,signal,antenna

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m13 7 3-3"/><path d="M14 14a2 2 0 0 1 2-2"/><path d="M14 4a2 2 0 0 1 2 2"/><path d="m16 2 4 4"/><path d="m8 7-3 3"/><path d="m14 17 3 3"/><path d="m16 16 4 4"/><path d="m2 22 5-5"/><path d="M3.83 8.83a4 4 0 0 0 0 5.66l1.42-1.42a2 2 0 0 1 0-2.82Z"/><path d="M9 5.41a2 2 0 0 1 2.83 0l3.18 3.18a4 4 0 0 1 0 5.66"/></svg>
```

## moon-star

**关键词**: 星月,moon-star,night,sky,space,astronomy,dark,mode

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/><path d="M19 3v4"/><path d="M21 5h-4"/></svg>
```

## atom

**关键词**: 原子,atom,science,physics,molecule,particle,nuclear,chemistry

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><path d="M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z"/><path d="M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z"/></svg>
```

## orbit

**关键词**: 轨道,orbit,space,planet,solar,system,rotate,circle

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><circle cx="19" cy="6" r="2"/><path d="M12 9a7 7 0 0 1 7 7c0 1.9-.8 3.6-2.1 4.7-1.3 1.1-3 1.7-4.9 1.7-3.9 0-7-3.1-7-7s3.1-7 7-7c1.9 0 3.6.8 4.7 2.1"/></svg>
```

## telescope

**关键词**: 望远镜,telescope,observe,astronomy,space,star,gaze,view

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m10.065 12.493-6.18 1.318a.934.934 0 0 0-.75.919v.04c0 .48.45.844.93.805l5.44-.528"/><path d="m13.116 15.992-1.318 6.18a.934.934 0 0 0 .919.75h.039c.48 0 .844-.45.805-.93l.528-5.44"/><path d="m15.489 14.428 3.026-3.026a2 2 0 0 0 0-2.828l-.077-.077a2 2 0 0 0-2.828 0L12.584 11.52"/><path d="m16.5 6.5-2 2"/><path d="M17 10a2 2 0 0 0 0-4H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h2"/></svg>
```

## robot

**关键词**: 机器人,robot,ai,machine,automation,android,cyborg,tech

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="10" x="3" y="11" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4"/><line x1="8" y1="16" x2="8.01" y2="16"/><line x1="16" y1="16" x2="16.01" y2="16"/></svg>
```
